# Needed for T1505.003
# mkdir C:\inetpub\wwwroot
