#pragma once

#include <string>

std::wstring GetComputerDNSHostname();
