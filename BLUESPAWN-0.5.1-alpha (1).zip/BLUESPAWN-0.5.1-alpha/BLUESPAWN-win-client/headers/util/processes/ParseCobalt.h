#pragma once

#include "util/wrappers.hpp"

bool DumpBeaconInformation(const MemoryWrapper<>& memory);