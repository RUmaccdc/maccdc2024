find ~/BLUESPAWN/docs/media/scans/ -type f -mtime +1 -exec rm {} +
