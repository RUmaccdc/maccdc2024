#! /usr/bin/env python

import bloodhound

bloodhound.main()
